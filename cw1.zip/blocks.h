#ifndef BLOCKS_H
#define BLOCKS_H

// This class marks as object as blocking tom from walking here
class Blocks{};

#endif // BLOCKS_H
